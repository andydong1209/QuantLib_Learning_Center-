#include <ql/quantlib.hpp>

#include <iostream>
#include <cstdlib>

using namespace std;
using namespace QuantLib;

namespace QuantLib
{
	int value = 1;
	Time t = 1.01;
}


int main()
{
	std::cout << "QuantLib-C++ Dong Ver 1.0, based on QL-C++ Ver 1.0.1.\n" << std::endl;
	
	QuantLib::Date mydate(12, Aug, 2005);	
	std::cout << mydate << std::endl;
	std::cout << QuantLib::value << std::endl;
	std::cout << QuantLib::t << std::endl << std::endl;


	system("pause");

	return 0;
}

