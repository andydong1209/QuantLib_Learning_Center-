//-------------------------------------------------------------------------------------------//
//********************************** Andy Dong v1.0 2011 ************************************//
//-------------------------------------------------------------------------------------------//

/*! \file version.hpp
    \brief Version number  */

#ifndef quantlib_version_hpp
#define quantlib_version_hpp
#include <ql/qldefines.hpp>

/*! \addtogroup macros */

//! version string
#ifdef QL_DEBUG
    #define QL_VERSION "1.0.1-debug"
#else
    #define QL_VERSION "1.0.1"
#endif

//! version hexadecimal number
#define QL_HEX_VERSION 0x010001f0

//! version string for output lib name
#define QL_LIB_VERSION "1_0_1"

#endif
