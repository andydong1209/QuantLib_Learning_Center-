//-------------------------------------------------------------------------------------------//
//********************************** Andy Dong v1.0 2011 ************************************//
//-------------------------------------------------------------------------------------------//

#ifndef quantlib_autolink_hpp
#define quantlib_autolink_hpp

#include <ql/version.hpp>
#include <boost/config.hpp>

// select toolset:
#if (_MSC_VER < 1310)
#  error "unsupported Microsoft compiler"
#elif (_MSC_VER == 1310)
#  define QL_LIB_TOOLSET "vc71"
#elif (_MSC_VER == 1400)
#  define QL_LIB_TOOLSET "vc80"
#elif (_MSC_VER == 1500)
#  ifdef x64
#    define QL_LIB_TOOLSET "vc90-x64"
#  else
#    define QL_LIB_TOOLSET "vc90"
#  endif
#elif (_MSC_VER == 1900)
#  ifdef x64
#    define QL_LIB_TOOLSET "vc140-x64"
#  else
#    define QL_LIB_TOOLSET "vc140"
#  endif
#else
#  error "unknown Microsoft compiler"
#endif


/*** libraries to be linked ***/
// select thread opt:
#ifdef _MT
#  define QL_LIB_THREAD_OPT "-mt"
#else
#  define QL_LIB_THREAD_OPT
#endif

// select linkage opt:
#ifdef _DLL
#  if defined(_DEBUG)
#    define QL_LIB_RT_OPT "-gd"
#  else
#    define QL_LIB_RT_OPT
#  endif
#else
#  if defined(_DEBUG)
#    define QL_LIB_RT_OPT "-sgd"
#  else
#    define QL_LIB_RT_OPT "-s"
#  endif
#endif

//#define QL_LIB_NAME "QuantLib-" QL_LIB_TOOLSET QL_LIB_THREAD_OPT QL_LIB_RT_OPT ".lib"

//#pragma comment(lib, QL_LIB_NAME)
// exe version does not need Link QuantLib.Lib

//Usage:
//The following pragma causes the linker to search for the EMAPI.LIB library while linking.
//    #pragma comment( lib, "emapi" )
//The linker searches first in the current working directory and then in the path specified 
//in the LIB environment variable.

#ifdef BOOST_LIB_DIAGNOSTIC
#  pragma message("Will (need to) link to lib file: " QL_LIB_NAME)
#endif

#endif
