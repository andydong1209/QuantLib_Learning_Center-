//-------------------------------------------------------------------------------------------//
//********************************** Andy Dong v1.0 2011 ************************************//
//-------------------------------------------------------------------------------------------//

#ifndef quantlib_types_hpp
#define quantlib_types_hpp

#include <ql/qldefines.hpp>
#include <cstddef>

namespace QuantLib 
{
    //! integer number
    /*! \ingroup types */
    typedef QL_INTEGER Integer;

    //! large integer number
    /*! \ingroup types */
    typedef QL_BIG_INTEGER BigInteger;

    //! positive integer
    /*! \ingroup types */
    typedef unsigned QL_INTEGER Natural;

    //! large positive integer
    typedef unsigned QL_BIG_INTEGER BigNatural;

    //! real number
    /*! \ingroup types */
    typedef QL_REAL Real;

    //! decimal number
    /*! \ingroup types */
    typedef Real Decimal;

    //! size of a container
    /*! \ingroup types */
    typedef std::size_t Size;

    //! continuous quantity with 1-year units
    /*! \ingroup types */
    typedef Real Time;

    //! discount factor between dates
    /*! \ingroup types */
    typedef Real DiscountFactor;

    //! interest rates
    /*! \ingroup types */
    typedef Real Rate;

    //! spreads on interest rates
    /*! \ingroup types */
    typedef Real Spread;

    //! volatility
    /*! \ingroup types */
    typedef Real Volatility;

}

#endif
