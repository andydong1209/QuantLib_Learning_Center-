//-------------------------------------------------------------------------------------------//
//********************************** Andy Dong v1.0 2011 ************************************//
//-------------------------------------------------------------------------------------------//

#ifndef quantlib_config_msvc_hpp
#define quantlib_config_msvc_hpp
#include <ql/userconfig.hpp>

/************************************************************************************
   System configuration section: do not modify the following definitions.
 ************************************************************************************/

// force undefining min and max macros
#ifndef NOMINMAX
#  define NOMINMAX
#endif
#ifdef min
#  undef min
#endif
#ifdef max
#  undef max
#endif

// leave outside here common configs
#define _USE_MATH_DEFINES  // let <cmath> define math constants
#define QL_PATCH_MSVC  // more granularity below

// select toolset:
#if (_MSC_VER < 1310)
	#error "unsupported Microsoft compiler"

#elif (_MSC_VER == 1310)
	// move inside here configs specific to VC++ 7.1 (.Net 2003)
	#define QL_PATCH_MSVC71
	#define QL_WORKING_BOOST_STREAMS
	// for some reason, Koenig lookup emits a warning
	#pragma warning(disable: 4675)
	// also, sending a size_t to an output stream causes a warning.
	// we disable it and rely on other compilers to catch genuine problems.
	#pragma warning(disable: 4267)
	// same for Boost.Function using a supposedly non-standard extension
	#pragma warning(disable: 4224)

#elif (_MSC_VER == 1400)
	// move inside here configs specific to VC++ 8 (2005)
	#ifndef _SCL_SECURE_NO_DEPRECATE
		#define _SCL_SECURE_NO_DEPRECATE
	#endif	
	#ifndef _CRT_SECURE_NO_DEPRECATE
		#define _CRT_SECURE_NO_DEPRECATE
	#endif
	#define QL_PATCH_MSVC80
	#define QL_WORKING_BOOST_STREAMS
	// see the corresponding pragmas in the 7.1 section
	#pragma warning(disable: 4267)
	#pragma warning(disable: 4224)
	// non-ASCII characters - Disabling this warning here is ineffective
	// and the change has been made instead under project properties
	//#pragma warning(disable: 4819)

#elif (_MSC_VER == 1500)
	// move inside here configs specific to VC++ 9 (2008)
	#ifndef _SCL_SECURE_NO_DEPRECATE
		#define _SCL_SECURE_NO_DEPRECATE
	#endif
	#ifndef _CRT_SECURE_NO_DEPRECATE
		#define _CRT_SECURE_NO_DEPRECATE
	#endif
	#define QL_PATCH_MSVC90
	#define QL_WORKING_BOOST_STREAMS
	// see the corresponding pragmas in the 7.1 section
	#pragma warning(disable: 4267)
	#pragma warning(disable: 4224)

#else
	#error "unknown Microsoft compiler"

#endif

#ifndef _CPPRTTI
	#if (_MSC_VER >= 1300) // VC++ 7.0 (.Net) and later
		#error Enable Run-Time Type Info (Property Pages | C/C++ | Language)
	#else
		#error Enable Run-Time Type Information (Project Settings | C/C++ | C++ Language)
	#endif
#endif

#endif
