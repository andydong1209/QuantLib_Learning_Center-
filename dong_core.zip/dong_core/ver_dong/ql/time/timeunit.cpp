//-------------------------------------------------------------------------------------------//
//********************************** Andy Dong v1.0 2011 ************************************//
//-------------------------------------------------------------------------------------------//

#include <ql/time/timeunit.hpp>
#include <ql/types.hpp>
#include <ql/errors.hpp>

namespace QuantLib 
{
    // timeunit formatting
    std::ostream& operator<<(std::ostream& out, const TimeUnit& timeunit) 
	{
        switch (timeunit) 
		{
            case Years:
                return out << "Years";
            case Months:
                return out << "Months";
            case Weeks:
                return out << "Weeks";
            case Days:
                return out << "Days";
            default:
                QL_FAIL("unknown TimeUnit");
        }
    }
}
