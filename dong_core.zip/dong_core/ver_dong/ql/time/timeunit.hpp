//-------------------------------------------------------------------------------------------//
//********************************** Andy Dong v1.0 2011 ************************************//
//-------------------------------------------------------------------------------------------//

#ifndef quantlib_timeunit_hpp
#define quantlib_timeunit_hpp

#include <ql/qldefines.hpp>
#include <ostream>

namespace QuantLib 
{
    //! Units used to describe time periods
    enum TimeUnit 
	{ 
		Days,
		Weeks,
		Months,
		Years
    };

    /*! \relates TimeUnit */
    std::ostream& operator<<(std::ostream&, const TimeUnit&);
}

#endif
