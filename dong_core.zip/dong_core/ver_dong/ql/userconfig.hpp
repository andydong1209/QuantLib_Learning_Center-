//-------------------------------------------------------------------------------------------//
//********************************** Andy Dong v1.0 2011 ************************************//
//-------------------------------------------------------------------------------------------//

#ifndef quantlib_config_hpp
#define quantlib_config_hpp

/***************************************************************
   User configuration section:
   modify the following definitions to suit your preferences.

   Do not modify this file if you are using a Linux/Unix system:
   it will not be read by the compiler. The definitions below
   will be provided by running ./configure instead.
****************************************************************/

/* Define this if error messages should include current function information. */
#ifndef QL_ERROR_FUNCTIONS
//#   define QL_ERROR_FUNCTIONS
#endif

/* Define this if error messages should include file and line information. */
#ifndef QL_ERROR_LINES
//#   define QL_ERROR_LINES
#endif

/* Define this if tracing messages should be allowed (whether they are
   actually emitted will depend on run-time settings.) */
#ifndef QL_ENABLE_TRACING
//#   define QL_ENABLE_TRACING
#endif

/* Define this if negative yield rates should be allowed. This might not be safe. */
#ifndef QL_NEGATIVE_RATES
//#   define QL_NEGATIVE_RATES
#endif

/* Define this if extra safety checks should be performed. This can degrade performance. */
#ifndef QL_EXTRA_SAFETY_CHECKS
//#   define QL_EXTRA_SAFETY_CHECKS
#endif

/* Define this if you want to disable deprecated code. */
#ifndef QL_DISABLE_DEPRECATED
//#   define QL_DISABLE_DEPRECATED
#endif

/* Define this to use indexed coupons instead of par coupons in floating legs. */
#ifndef QL_USE_INDEXED_COUPON
//#   define QL_USE_INDEXED_COUPON
#endif

/* Define this to have singletons return different instances for different sessions.
   You will have to provide and link with the library a sessionId() function in namespace
   QuantLib, returning a different session id for each session.*/
#ifndef QL_ENABLE_SESSIONS
//#   define QL_ENABLE_SESSIONS
#endif

#endif
