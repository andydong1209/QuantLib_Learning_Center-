#! /usr/bin/python3

import sys
sys.stdout.write("Hello from Python %s\n" % (sys.version,))
